
import { motion } from "framer-motion";
import { Progress } from "@/components/ui/progress";
import { 
  Code, 
  Database, 
  Layout, 
  Server, 
  Cloud, 
  Terminal, 
  Workflow, 
  GitBranch 
} from "lucide-react";
import { SkillCard, SkillProps } from "@/components/SkillCard";
import SectionTitle from "@/components/SectionTitle";

const Skills = () => {
  const technicalSkills = [
    { name: "JavaScript/TypeScript", progress: 95 },
    { name: "React/Next.js", progress: 90 },
    { name: "HTML/CSS/Tailwind", progress: 90 },
    { name: "Node.js/Express", progress: 85 },
    { name: "MongoDB/PostgreSQL", progress: 80 },
    { name: "GraphQL", progress: 75 },
    { name: "DevOps/CI/CD", progress: 70 },
    { name: "Testing (Jest, Cypress)", progress: 80 },
  ];

  const skillCategories: SkillProps[] = [
    {
      title: "Frontend Development",
      description: "Creating responsive, accessible, and performant user interfaces with React, TypeScript, and modern CSS.",
      icon: <Layout className="h-6 w-6 text-primary" />,
      color: "bg-primary/10",
    },
    {
      title: "Backend Development",
      description: "Building robust APIs and server-side applications with Node.js, Express, and various databases.",
      icon: <Server className="h-6 w-6 text-accent" />,
      color: "bg-accent/10",
    },
    {
      title: "Database Design",
      description: "Designing efficient database schemas, writing optimized queries, and managing data relationships.",
      icon: <Database className="h-6 w-6 text-emerald-500" />,
      color: "bg-emerald-500/10",
    },
    {
      title: "UI/UX Design",
      description: "Creating intuitive interfaces with a focus on usability, accessibility, and user experience.",
      icon: <Layout className="h-6 w-6 text-amber-500" />,
      color: "bg-amber-500/10",
    },
    {
      title: "Cloud Services",
      description: "Deploying and scaling applications on AWS, GCP, and other cloud platforms.",
      icon: <Cloud className="h-6 w-6 text-blue-500" />,
      color: "bg-blue-500/10",
    },
    {
      title: "DevOps",
      description: "Setting up CI/CD pipelines, containerization with Docker, and infrastructure as code with Terraform.",
      icon: <Workflow className="h-6 w-6 text-fuchsia-500" />,
      color: "bg-fuchsia-500/10",
    },
    {
      title: "Version Control",
      description: "Managing code with Git, GitHub workflows, code reviews, and collaborative development.",
      icon: <GitBranch className="h-6 w-6 text-rose-500" />,
      color: "bg-rose-500/10",
    },
    {
      title: "Command Line",
      description: "Proficient with Unix/Linux command line, shell scripting, and automation.",
      icon: <Terminal className="h-6 w-6 text-gray-500" />,
      color: "bg-gray-500/10",
    },
  ];
  
  const technologies = [
    "JavaScript", "TypeScript", "React", "Next.js", "Node.js", "Express", 
    "Tailwind CSS", "HTML5", "CSS3", "MongoDB", "PostgreSQL", "GraphQL", 
    "Redux", "Zustand", "Jest", "Cypress", "Docker", "AWS", "Firebase", 
    "Git", "GitHub Actions", "Webpack", "Vite", "Material UI", "Chakra UI", 
    "Storybook", "REST APIs", "WebSockets"
  ];

  return (
    <>
      <section className="py-12">
        <div className="container px-4 mx-auto">
          <SectionTitle
            subtitle="Expertise"
            title="Technical Skills & Capabilities"
            description="An overview of my technical skills, expertise areas, and technologies I work with."
          />
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* Skill Bars */}
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5 }}
              className="glass-card p-6 rounded-xl h-full"
            >
              <h3 className="text-xl font-bold mb-6">Core Competencies</h3>
              
              <div className="space-y-6">
                {technicalSkills.map((skill, index) => (
                  <div key={index}>
                    <div className="flex justify-between mb-2">
                      <span className="font-medium">{skill.name}</span>
                      <span className="text-primary">{skill.progress}%</span>
                    </div>
                    <Progress value={skill.progress} className="h-2" />
                  </div>
                ))}
              </div>
            </motion.div>
            
            {/* Technologies List */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="glass-card p-6 rounded-xl h-full"
            >
              <h3 className="text-xl font-bold mb-6">Technologies & Tools</h3>
              
              <div className="flex flex-wrap gap-2">
                {technologies.map((tech, index) => (
                  <span 
                    key={index}
                    className="bg-secondary px-3 py-1 rounded-full text-sm font-medium"
                  >
                    {tech}
                  </span>
                ))}
              </div>
            </motion.div>
          </div>
        </div>
      </section>
      
      {/* Skill Categories */}
      <section className="py-16 bg-secondary/20 backdrop-blur-sm">
        <div className="container px-4 mx-auto">
          <SectionTitle
            subtitle="Areas of Expertise"
            title="What I Bring to the Table"
            description="My skill set spans across different areas of software development."
          />
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {skillCategories.map((skill, index) => (
              <SkillCard key={index} skill={skill} />
            ))}
          </div>
        </div>
      </section>
      
      {/* Certifications */}
      <section className="py-16">
        <div className="container px-4 mx-auto">
          <SectionTitle
            subtitle="Certifications"
            title="Professional Certifications"
            description="Formal training and certifications I've completed to enhance my skills."
          />
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl mx-auto">
            {[
              {
                name: "AWS Certified Developer",
                issuer: "Amazon Web Services",
                year: "2022",
                logo: <Cloud className="h-8 w-8 text-blue-500" />,
              },
              {
                name: "Professional Scrum Master",
                issuer: "Scrum.org",
                year: "2021",
                logo: <Workflow className="h-8 w-8 text-green-500" />,
              },
              {
                name: "React Certification",
                issuer: "Meta",
                year: "2020",
                logo: <Code className="h-8 w-8 text-primary" />,
              },
            ].map((cert, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5 }}
                className="glass-card p-6 rounded-xl text-center"
              >
                <div className="flex justify-center mb-4">
                  {cert.logo}
                </div>
                
                <h3 className="text-lg font-bold mb-1">{cert.name}</h3>
                <p className="text-primary/90 text-sm mb-1">{cert.issuer}</p>
                <p className="text-muted-foreground text-sm">{cert.year}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
    </>
  );
};

export default Skills;