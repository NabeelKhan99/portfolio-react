
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Download, Code, GitBranch, Users } from "lucide-react";
import SectionTitle from "@/components/SectionTitle";
import { useEffect, useState } from "react";

const About = () => {
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });
  
  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      setMousePosition({ x: e.clientX, y: e.clientY });
    };
    
    window.addEventListener("mousemove", handleMouseMove);
    return () => window.removeEventListener("mousemove", handleMouseMove);
  }, []);

  return (
    <>
      <section className="py-12">
        <div className="container px-4 mx-auto">
          <SectionTitle
            subtitle="About Me"
            title="My Journey as a Developer"
            description="Get to know me, my background, what drives me, and where I'm headed."
          />
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5 }}
              className="relative"
            >
              {/* Animated glowing orbs */}
              <motion.div 
                className="absolute -top-8 -left-8 w-28 h-28 bg-primary/30 rounded-full blur-xl z-0"
                animate={{
                  scale: [1, 1.2, 1],
                  opacity: [0.3, 0.6, 0.3],
                }}
                transition={{
                  duration: 5,
                  repeat: Infinity,
                  ease: "easeInOut",
                }}
              />
              
              <motion.div 
                className="absolute -bottom-8 -right-8 w-28 h-28 bg-accent/30 rounded-full blur-xl z-0"
                animate={{
                  scale: [1, 1.3, 1],
                  opacity: [0.3, 0.7, 0.3],
                }}
                transition={{
                  duration: 4,
                  repeat: Infinity,
                  ease: "easeInOut",
                  delay: 0.5,
                }}
              />
              
              <motion.div 
                className="absolute top-1/2 -translate-y-1/2 -left-4 w-16 h-16 bg-blue-400/20 rounded-full blur-lg z-0"
                animate={{
                  scale: [1, 1.4, 1],
                  opacity: [0.2, 0.5, 0.2],
                }}
                transition={{
                  duration: 7,
                  repeat: Infinity,
                  ease: "easeInOut",
                  delay: 1,
                }}
              />
              
              {/* Image container with parallax effect */}
              <div className="relative z-10 border border-white/10 p-1 rounded-2xl glass-card overflow-hidden shadow-2xl">
                {/* Subtle light reflection overlay */}
                <motion.div 
                  className="absolute inset-0 bg-gradient-to-tr from-transparent via-white/10 to-transparent z-10 pointer-events-none rounded-2xl"
                  style={{
                    backgroundPosition: `${mousePosition.x / 20}px ${mousePosition.y / 20}px`,
                  }}
                />
                
                {/* Magical particle effect */}
                <div className="absolute inset-0 overflow-hidden rounded-2xl">
                  {Array.from({ length: 6 }).map((_, i) => (
                    <motion.div
                      key={i}
                      className="absolute w-1.5 h-1.5 bg-primary/60 rounded-full"
                      style={{
                        top: `${30 + (i * 10)}%`,
                        left: `${10 + (i * 15)}%`,
                      }}
                      animate={{
                        y: [0, -30, 0],
                        opacity: [0, 1, 0],
                      }}
                      transition={{
                        duration: 4 + i,
                        repeat: Infinity,
                        delay: i * 0.5,
                        ease: "easeInOut",
                      }}
                    />
                  ))}
                </div>
                
                {/* Main image with hover effect */}
                <motion.div 
                  className="relative overflow-hidden rounded-xl aspect-square max-w-md"
                  whileHover={{ scale: 1.02 }}
                  transition={{ duration: 0.3 }}
                >
                  <motion.img 
                    src="https://images.unsplash.com/photo-1603575448878-868a20723f5d?q=80&w=1170&auto=format&fit=crop" 
                    alt="Developer Portrait" 
                    className="w-full h-full object-cover"
                    animate={{ 
                      scale: 1.05
                    }}
                    whileHover={{ 
                      scale: 1.12,
                      filter: "brightness(1.1)"
                    }}
                    transition={{ 
                      duration: 0.5,
                      scale: {
                        type: "spring",
                        stiffness: 200,
                        damping: 25
                      }
                    }}
                    style={{
                      transform: `perspective(1000px) rotateX(${(mousePosition.y - window.innerHeight / 2) / 50}deg) rotateY(${-(mousePosition.x - window.innerWidth / 2) / 50}deg)`,
                    }}
                  />
                </motion.div>
              </div>
            </motion.div>
            
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              <h3 className="text-2xl font-bold mb-4">Hello, I'm <span className="text-gradient">John Doe</span></h3>
              
              <p className="text-muted-foreground mb-4">
                I'm a passionate software developer with over 5 years of experience building web applications and digital products. My journey in tech started when I was in college, tinkering with websites and learning to code in my free time.
              </p>
              
              <p className="text-muted-foreground mb-6">
                Over the years, I've had the opportunity to work with diverse teams, from startups to large corporations, helping them build innovative solutions. I specialize in JavaScript/TypeScript, React, and Node.js, with a strong foundation in UI/UX principles.
              </p>
              
              <div className="flex flex-wrap gap-4">
                <Button asChild>
                  <a href="/resume.pdf" download>
                    <Download className="mr-2 h-4 w-4" /> Download Resume
                  </a>
                </Button>
              </div>
            </motion.div>
          </div>
        </div>
      </section>
      
      {/* Experience Section */}
      <section className="py-16 bg-secondary/20 backdrop-blur-sm">
        <div className="container px-4 mx-auto">
          <SectionTitle
            subtitle="Experience"
            title="My Professional Journey"
            description="A look at my professional experience and the companies I've worked with."
          />
          
          <div className="space-y-10 max-w-3xl mx-auto">
            {[
              {
                title: "Senior Frontend Developer",
                company: "TechCorp Solutions",
                period: "2021 - Present",
                description: "Lead the frontend development team, architecting and implementing responsive web applications using React, TypeScript, and Next.js. Improved website performance by 40% and implemented CI/CD pipelines.",
                icon: <Code className="h-6 w-6 text-primary" />,
              },
              {
                title: "Full Stack Developer",
                company: "InnovateTech",
                period: "2018 - 2021",
                description: "Developed and maintained full-stack applications using React, Node.js, and MongoDB. Implemented authentication systems and RESTful APIs for various client projects.",
                icon: <GitBranch className="h-6 w-6 text-accent" />,
              },
              {
                title: "Web Developer",
                company: "DigitalCraft Agency",
                period: "2016 - 2018",
                description: "Collaborated in cross-functional teams to build responsive websites and e-commerce platforms for clients across various industries.",
                icon: <Users className="h-6 w-6 text-amber-500" />,
              },
            ].map((experience, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5 }}
                className="glass-card p-6 rounded-xl"
              >
                <div className="flex flex-col md:flex-row gap-4">
                  <div className="w-12 h-12 bg-secondary rounded-lg flex items-center justify-center shrink-0">
                    {experience.icon}
                  </div>
                  
                  <div>
                    <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-2 mb-2">
                      <h3 className="text-xl font-bold">{experience.title}</h3>
                      <span className="text-sm font-medium bg-muted px-3 py-1 rounded-full">
                        {experience.period}
                      </span>
                    </div>
                    
                    <p className="text-primary/90 font-medium mb-3">{experience.company}</p>
                    <p className="text-muted-foreground">{experience.description}</p>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
      
      {/* Education Section */}
      <section className="py-16">
        <div className="container px-4 mx-auto">
          <SectionTitle
            subtitle="Education"
            title="Academic Background"
            description="My educational journey and qualifications."
          />
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-3xl mx-auto">
            {[
              {
                degree: "Master of Science in Computer Science",
                school: "Tech University",
                year: "2014 - 2016",
                description: "Specialized in Human-Computer Interaction and User Experience Design.",
              },
              {
                degree: "Bachelor of Science in Software Engineering",
                school: "State University",
                year: "2010 - 2014",
                description: "Graduated with honors. Focused on software development methodologies and programming fundamentals.",
              },
            ].map((education, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5 }}
                className="glass-card p-6 rounded-xl h-full"
              >
                <h3 className="text-xl font-bold mb-2">{education.degree}</h3>
                
                <div className="flex items-center justify-between mb-4">
                  <p className="text-primary/90 font-medium">{education.school}</p>
                  <span className="text-sm bg-muted px-3 py-1 rounded-full">
                    {education.year}
                  </span>
                </div>
                
                <p className="text-muted-foreground">{education.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
    </>
  );
};

export default About;