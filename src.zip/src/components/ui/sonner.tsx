// src/components/ui/sonner.tsx
import * as React from 'react';

// Define the Toaster component
export const Toaster = () => {
  return (
    <div>
      <p>Toaster Component</p>
    </div>
  );
};

// Export the Toaster component
export default Toaster;